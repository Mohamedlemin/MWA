const mongoose = require("mongoose")
const pmpl = mongoose.model(process.env.PMPL_MODEL)

// --------------------------------------------------------
const getAll = function(req, res) {
  let offset = 0;
  let count = 10;
  if (req.query && req.query.offset) {
    offset = parseInt(req.query.offset, 10);
    if (isNaN(offset) || offset < 0) {
      return res.status(400).json({ error: 'Invalid offset value' });
    }
  }
  if (req.query && req.query.count) {
    count = parseInt(req.query.count, 10);
    if (isNaN(count) || count < 1) {
      return res.status(400).json({ error: 'Invalid count value' });
    }
  }
  pmpl
    .find()
    .skip(offset)
    .limit(count)
    .exec(function(err, pmpls) {
      if (err) {
        console.error('Error retrieving PMPLs:', err);
        return res.status(500).json({ error: 'Failed to retrieve PMPLs' });
      }
      console.log('Found PMPLs:', pmpls.length);
      return res.json(pmpls);
    });
};

// --------------------------------------------------------

const addOne = function (req,res) {
    const { title, prize, region, teams } = req.body;

    const newPMPL = new pmpl({
        title,
        prize,
        region,
        teams
      });

    console.log(newPMPL)

    pmpl.create(newPMPL,function (err,resp) {
        const response = {status : 201 ,message : resp }
        if (err) {
            console.log(err);
            response.status(500)
            response.message = err
        }
        res.status(response.status).json(response.message)
    });
}

// --------------------------------------------------------

const FullupdatePMPL = function (req, res) {
    const pmplID = req.params.pmplID;
    const updatedData = req.body;
  
    pmpl.findByIdAndUpdate(
      pmplID,
      updatedData,
      { new: true },
      function (err, updatedPMPL) {
        if (err) {
          console.error('Error updating PMPL:', err);
          res.status(500).json({ error: 'Failed to update PMPL' });
        } else if (!updatedPMPL) {
          res.status(404).json({ error: 'PMPL not found' });
        } else {
          console.log('Updated PMPL:', updatedPMPL);
          res.status(200).json(updatedPMPL);
        }
      }
    );
  };

// --------------------------------------------------------

  const patchUpdate= function (req, res) {
    const pmplID = req.params.pmplID;
    const updatedData = req.body;
  
    pmpl.findByIdAndUpdate(
      pmplID,
      { $set: updatedData },
      { new: true },
      function (err, updatedPMPL) {
        if (err) {
          console.error('Error updating PMPL:', err);
          res.status(500).json({ error: 'Failed to update PMPL' });
        } else if (!updatedPMPL) {
          res.status(404).json({ error: 'PMPL not found' });
        } else {
          console.log('Updated PMPL:', updatedPMPL);
          res.status(200).json(updatedPMPL);
        }
      }
    );
  };
  
// --------------------------------------------------------

const deletePMPL = function (req, res) {
    const pmplID = req.params.pmplID;
  
    pmpl.findByIdAndRemove(pmplID, function (err, deletedPMPL) {
      if (err) {
        console.error('Error deleting PMPL:', err);
        res.status(500).json({ error: 'Failed to delete PMPL' });
      } else if (!deletedPMPL) {
        res.status(404).json({ error: 'PMPL not found' });
      } else {
        console.log('Deleted PMPL:', deletedPMPL);
        res.status(200).json({ message: 'PMPL deleted successfully' });
      }
    });
  };

module.exports = {
    getAll,
    addOne,
    FullupdatePMPL,
    patchUpdate,
    deletePMPL
}